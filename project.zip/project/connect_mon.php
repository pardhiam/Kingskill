<?php
	$ma=new MongoClient();
	$db=$ma->userdata;
	$collec1=$db->info;
?>