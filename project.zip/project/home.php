<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>KingSkills</title>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
	
	<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/cart.css">

    
	<style type="text/css">
			.carousel-inner img {
   				width: 100%; /* Set width to 100% */
      			min-height:450px;
  			}
             /* Hide the carousel text when the screen is less than 600 pixels wide */
            @media (max-width: 600px) {
                .carousel-caption {
                    display: none; 
                }

	</style>
</head>
<body>
  <?php require 'func.php';
  	
  	
  ?>

	<!--navbar -->
	<nav class="navbar navbar-toggleable-md navbar-light bg-faded sticky-top">
		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
	    	<span class="navbar-toggler-icon"></span>
	  	</button>
  	
  		<!-- Image and text -->
		<a class="navbar-brand" href="#">
	    	<img src="http://vignette2.wikia.nocookie.net/clubpenguin/images/e/e5/King%27s_Crown_clothing_icon_ID_667.png/revision/latest?cb=20141117234124" width="30" height="30" class="d-inline-block align-top" alt="">
	    	KingSkills
 		</a>

 		<div class="collapse navbar-collapse" id="navbarNavDropdown">
 			<form class="form-inline">
    			<input class="form-control mr-sm-2" type="text" placeholder="Search">
    			<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
  			</form>

  			<!-- nav-right-auto -->
			<ul class="nav navbar-nav ml-auto">
		    	
		      	<?php 
                if(!isloggedin())
                {
                ?>
		      	<li class="nav-item active">
		           	<a class="nav-link" href="#" data-toggle="modal" data-target="#exampleModalLong">Sign-In</a>
		        
		      	</li>
		      	<li class="nav-item active">
                    <a class="nav-link" href="#" data-toggle="modal" data-target="#exampleModalReg">
                        Join
                    </a>                    
		      	</li>

                <?php 
                }
                if(isloggedin())
                {
                ?>

                    <li class="nav-item">
                        <a class="nav-link" href="#">Become a seller <span class="sr-only">(current)</span></a>
                    </li>
                    
    	        
                
		      	
		      	<li class="nav-item dropdown">
		        	<a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		          Profile
		        	</a>


			        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
			          <a font-color:"blue" class="dropdown-item"> 
			          <?php
		        		echo $_SESSION['email']; 
		        	  ?>
		        	  </a>
		        	  <br>
			          <a class="dropdown-item" href="seller_profile_form.php">Update Basic Info</a>
			          <a class="dropdown-item" href="#">Update Skills</a>
			          <a class="dropdown-item" href="#">Orders</a>
			        </div>
		      	</li>
		      	<li class="nav-item">
                    <a class="nav-link" href="#" id="cart"><i class="fa fa-shopping-cart"></i> Cart <span class="badge">3</span></a>
                </li>

		     	<li class="nav-item active">
                       <a class="nav-link" href="logout.php" >Logout</a>
                </li>
        		  		
		  		<?php
                }
                ?>

		    </ul>
		</div>
	</nav>
   
	<!-- Modal login -->
	<div class="modal fade" id="exampleModalLong" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
	  <div class="modal-dialog login animated">
	    <div class="modal-content">
			
	        <div class="modal-header">
                	<h4 class="modal-title">Sign-in with</h4>
                	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>                        
            </div>
	    
	    	<div class="modal-body">
	      			<div class="box">
                        <div class="content">
                            <div class="social">
                                <a class="circle github" href="#">
                                    <i class="fa fa-github fa-fw"></i>
                                </a>
                                <a id="google_login" class="circle google" href="#">
                                    <i class="fa fa-google-plus-official" aria-hidden="true"></i>
                                </a>
                                <a id="facebook_login" class="circle facebook" href="/auth/facebook">
                                        <i class="fa fa-facebook fa-fw"></i>
                                </a>
                        	</div>
                             
                            <div class="division">
                                    <div class="line l"></div>
                                      <span>or</span>
                                    <div class="line r"></div>
                            </div>
                            <div class="error"></div>
                            
                            <div class="form loginBox">
                                <form method="POST" action="signIn.php" accept-charset="UTF-8">
                            	    <input id="email" class="form-control" type="text" placeholder="Email" name="email">
                            	    <input id="password" class="form-control" type="password" placeholder="Password" name="password">
                            	    <input class="btn btn-default btn-login" type="submit" value="Login" name="commit" >
                                </form>
                            </div>
                        </div>
                    </div>                    
	        </div>

	      <div class="modal-footer">
	        <div class="forgot login-footer">
                <span>Looking to 
                    <a href="javascript: showRegisterForm();">
                       	create an account
                    </a>
                        ?
                </span>
            </div>
	      </div>
	    </div>
	  </div>
	</div>

	<!-- Modal Register -->
	<div class="modal fade" id="exampleModalReg" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
	  <div class="modal-dialog login animated">

	    <div class="modal-content">
	        <div class="modal-header">
                	<h4 class="modal-title">Join Us by:</h4>
                	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>                        
            </div>
	    
	    	<div class="modal-body">
	      			<div class="box">
                        <div class="content">
                            <div class="social">
                                <a class="circle github" href="/auth/github">
                                    <i class="fa fa-github fa-fw"></i>
                                </a>
                                <a id="google_login" class="circle google" href="/auth/google_oauth2">
                                    <i class="fa fa-google-plus-official" aria-hidden="true"></i>
                                </a>
                                <a id="facebook_login" class="circle facebook" href="/auth/facebook">
                                        <i class="fa fa-facebook fa-fw"></i>
                                </a>
                        	</div>
                             
                            <div class="division">
                                    <div class="line l"></div>
                                      <span>or</span>
                                    <div class="line r"></div>
                            </div>
                            <div class="error"></div>
                            
                            <div class="form loginBox">
                                <form action = "registerUser.php" method="post" html="{:multipart=>true}" data-remote="true" action="/register" accept-charset="UTF-8">
                                            <input id="username" name="username" class="form-control"  placeholder="Username" name="username" required>
                                            <input id="email" class="form-control" type="text" placeholder="Email" name="email" required>
                                            <input id="password" class="form-control" type="password" placeholder="Password" name="pass" required>
                                            <!--<input id="password_confirmation" class="form-control" type="password" placeholder="Repeat Password" name="pass_c" required>-->
                                            <input class="btn btn-default btn-register" id="enter" type="submit" value="Create account" name="commit">
                            
                                            <div id="error"></div>
                                </form>
                            </div>                            
                        </div>
                    </div>
	        </div>

	         <div class="modal-footer">
	            <div class="forgot login-footer">
                        <span>Already have an account? 
                          <a href="javascript: showLoginForm();">Login</a>  
                        </span>
                </div>                    
	         </div>
	    </div>
	  </div>
	</div>


	<!-- Carousal slider -->
	<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
		<ol class="carousel-indicators">
	    	<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
	    	<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
	    	<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
	  	</ol>
  		<div class="carousel-inner" role="listbox" data-interval="100000">
    		<div class="carousel-item active">
      			<img class="d-block img-fluid" src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22800%22%20height%3D%22400%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20800%20400%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_15b5ec957d0%20text%20%7B%20fill%3A%23555%3Bfont-weight%3Anormal%3Bfont-family%3AHelvetica%2C%20monospace%3Bfont-size%3A40pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_15b5ec957d0%22%3E%3Crect%20width%3D%22800%22%20height%3D%22400%22%20fill%3D%22%23777%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22285.921875%22%20y%3D%22217.7%22%3EFirst%20slide%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E" alt="First slide">
     			<div class="carousel-caption d-none d-md-block">
    				<h3 font color="black">King Skills</h3>
    				<p font color="black">A perfect marketplace to sell your skills </p>
  				</div>	
    		</div>
    		<div class="carousel-item">
      			<img class="d-block img-fluid" src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22800%22%20height%3D%22400%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20800%20400%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_15b5e947fc2%20text%20%7B%20fill%3A%23444%3Bfont-weight%3Anormal%3Bfont-family%3AHelvetica%2C%20monospace%3Bfont-size%3A40pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_15b5e947fc2%22%3E%3Crect%20width%3D%22800%22%20height%3D%22400%22%20fill%3D%22%23666%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22247.3203125%22%20y%3D%22217.7%22%3ESecond%20slide%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E" alt="Second slide">
    		</div>
    		<div class="carousel-item">
      			<img class="d-block img-fluid" src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22800%22%20height%3D%22400%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20800%20400%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_15b5e947fc3%20text%20%7B%20fill%3A%23333%3Bfont-weight%3Anormal%3Bfont-family%3AHelvetica%2C%20monospace%3Bfont-size%3A40pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_15b5e947fc3%22%3E%3Crect%20width%3D%22800%22%20height%3D%22400%22%20fill%3D%22%23555%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22277%22%20y%3D%22217.7%22%3EThird%20slide%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E" alt="Third slide">
    		</div>
  		</div>
	  	<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
	    	<span class="carousel-control-prev-icon" aria-hidden="true"></span>
	    	<span class="sr-only">Previous</span>
	  	</a>
  		<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    		<span class="carousel-control-next-icon" aria-hidden="true"></span>
    		<span class="sr-only">Next</span>
  		</a>
	</div>

<div class="container text-center">    
    <div class="mx-auto py-4" style="width: auto;">
        <h3>Explore the service market</h3>
    </div>
<br>
  <div class="row">
    <div class="col-sm-4">
      <div class="well">
       <p>Graphic & Design</p>
      </div>
      <div class="well">
       <p>Digital Marketing</p>
      </div>
    </div>
    <div class="col-sm-4">
      <img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image">
      <p>Current Project</p>
    </div>
    <div class="col-sm-4"> 
      <img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image">
      <p>Project 2</p>    
    </div>
    
  </div>
</div><br>

<!-- Products added to be added to the cart -->
<div class="container">
    <div class="row">
        <div class="col-md-12">
      <div class="col-xs-12 col-sm-6 col-md-3">
        <div class="thumbnail" >
          <img src="http://placehold.it/700x350&text=1" class="img-responsive">
          <div class="caption">
            <div class="row">
              <div class="col-md-4 col-sm-4 col-xs-4 price">
                  <h3 style="margin:5px auto;"><label>$1</label></h3>
              </div>
              <div class="col-md-8 col-sm-8 col-xs-8">
                <a href="#" class="btn btn-success btn-product"><span class="glyphicon glyphicon-shopping-cart"></span> Add 2 Cart</a>
                </div>
            </div>

            <p> </p>
          </div>
        </div>
      </div>
      <div class="col-xs-12 col-sm-6 col-md-3">
          <div class="thumbnail" >
          <img src="http://placehold.it/700x350&text=1" class="img-responsive">
          <div class="caption">
            <div class="row">
              <div class="col-md-4 col-sm-4 col-xs-4 price">
                  <h3 style="margin:5px auto;"><label>$2</label></h3>
              </div>
              <div class="col-md-8 col-sm-8 col-xs-8">
                <a href="#" class="btn btn-success btn-product"><span class="glyphicon glyphicon-shopping-cart"></span> Add 2 Cart</a>
                </div>
            </div>

            <p> </p>
          </div>
        </div>
      </div>
            <div class="col-xs-12 col-sm-6 col-md-3">
          <div class="thumbnail" >
          <img src="http://placehold.it/700x350&text=1" class="img-responsive">
          <div class="caption">
            <div class="row">
              <div class="col-md-4 col-sm-4 col-xs-4 price">
                  <h3 style="margin:5px auto;"><label>$3</label></h3>
              </div>
              <div class="col-md-8 col-sm-8 col-xs-8">
                <a href="#" class="btn btn-success btn-product"><span class="glyphicon glyphicon-shopping-cart"></span> Add 2 Cart</a>
                </div>
            </div>

            <p> </p>
          </div>
        </div>
      </div>
            <div class="col-xs-12 col-sm-6 col-md-3">
          <div class="thumbnail" >
          <img src="http://placehold.it/700x350&text=1" class="img-responsive">
          <div class="caption">
            <div class="row">
              <div class="col-md-4 col-sm-4 col-xs-4 price">
                  <h3 style="margin:5px auto;"><label>$4</label></h3>
              </div>
              <div class="col-md-8 col-sm-8 col-xs-8">
                <a href="#" class="btn btn-success btn-product"><span class="glyphicon glyphicon-shopping-cart"></span> Add 2 Cart</a>
                </div>
            </div>

            <p> </p>
          </div>
        </div>
      </div>
        </div> 

  </div>
</div>


<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>




 	<!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

</body>
</html>