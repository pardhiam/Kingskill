<?php
	require 'core.php';
	session_destroy();
	?>
	<script>
		alert('successfully logged out');
	</script>
	<?php
	header('refresh:0.3,url=home.php');
?>