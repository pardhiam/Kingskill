<?php
	require 'connect_mon.php';
	require 'core.php';
?>
<?php
	
	if(isset($_POST['commit']))
	{
		$email=$_POST['email'];
		$pass=$_POST['password'];
		
		/*$array=array(
			"Email" => $email,
			"Password"=>$pass,		
		);
		*/

		$check = $collec1->findOne(array("Email"=> $email));
		if(empty($check))
		{
			echo "Not found";
		}
		else
		{
		
			$doc_pass = $check['Password'];
			
			if($pass==$doc_pass)
			{
				$_SESSION['email']=$email;
				?>
				<script>
					alert("Hi, You have successfully logged in!");

				</script>
				<?php
				header('refresh:0.3,url=home.php');
				

			}

		}

	}
?>
		
