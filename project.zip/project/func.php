<?php
 require 'core.php';
  function isloggedin()
  {
	  if (isset($_SESSION['email']))
	  	return true;
	  else
	  	return false;
  }
?>